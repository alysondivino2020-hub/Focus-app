import { dateTime, addMinutes } from './utils.js';

let browserTimers = [];

function capacitorRuntime() {
  return window.Capacitor || null;
}

function localNotificationsPlugin() {
  const runtime = capacitorRuntime();
  if (!runtime) return null;
  if (runtime.Plugins?.LocalNotifications) return runtime.Plugins.LocalNotifications;
  if (typeof runtime.registerPlugin === 'function') {
    try {
      return runtime.registerPlugin('LocalNotifications');
    } catch {
      return null;
    }
  }
  return null;
}

export function isNative() {
  const runtime = capacitorRuntime();
  return Boolean(runtime?.isNativePlatform?.() || ['android','ios'].includes(runtime?.getPlatform?.()));
}

export async function requestNotificationPermission() {
  if (isNative()) {
    const plugin = localNotificationsPlugin();
    if (!plugin) return { granted: false, reason: 'Plugin nativo não carregado.' };
    const current = await plugin.checkPermissions();
    if (current.display === 'granted') return { granted: true };
    const result = await plugin.requestPermissions();
    return { granted: result.display === 'granted' };
  }
  if (!('Notification' in window)) return { granted: false, reason: 'Navegador sem suporte.' };
  const permission = await Notification.requestPermission();
  return { granted: permission === 'granted' };
}

export async function scheduleActivityNotifications(activity) {
  if (!activity.startTime || !activity.reminders?.length) return [];
  const scheduled = [];
  for (const reminder of activity.reminders) {
    const at = addMinutes(dateTime(activity.date, activity.startTime), -Number(reminder));
    if (at <= new Date()) continue;
    if (isNative()) {
      const plugin = localNotificationsPlugin();
      if (!plugin) continue;
      const id = numericId(`${activity.sourceId || activity.id}_${activity.date}_${reminder}`);
      await plugin.schedule({
        notifications: [{
          id,
          title: activity.title,
          body: `${activity.startTime} • ${activity.location || 'Atividade programada'}`,
          schedule: { at, allowWhileIdle: true },
          sound: 'focus_reminder.wav',
          extra: { activityId: activity.sourceId || activity.id, url: '/#agenda' },
          actionTypeId: 'FOCUS_ACTIVITY'
        }]
      });
      scheduled.push(id);
    } else {
      scheduleBrowserTimer(activity, at);
      scheduled.push(at.getTime());
    }
  }
  return scheduled;
}

function scheduleBrowserTimer(activity, at) {
  const delay = at.getTime() - Date.now();
  if (delay <= 0 || delay > 2147483647) return;
  const timer = setTimeout(() => {
    if (Notification.permission === 'granted') {
      const notification = new Notification(activity.title, {
        body: `${activity.startTime || ''} ${activity.location ? `• ${activity.location}` : ''}`,
        icon: 'assets/icons/icon-192.png',
        tag: activity.sourceId || activity.id,
        data: { activityId: activity.sourceId || activity.id, url: '/#agenda' }
      });
      notification.onclick = () => {
        window.focus();
        location.hash = '#agenda';
        notification.close();
      };
    }
  }, delay);
  browserTimers.push(timer);
}

export function clearBrowserSchedules() {
  browserTimers.forEach(clearTimeout);
  browserTimers = [];
}

export async function configureNativeActions() {
  if (!isNative()) return;
  const plugin = localNotificationsPlugin();
  if (!plugin?.registerActionTypes) return;
  await plugin.registerActionTypes({
    types: [{
      id: 'FOCUS_ACTIVITY',
      actions: [
        { id: 'complete', title: 'Concluir' },
        { id: 'snooze', title: 'Adiar 10 min' },
        { id: 'open', title: 'Abrir' }
      ]
    }]
  });
}

export async function listenNativeNotificationActions(callback) {
  if (!isNative()) return null;
  const plugin = localNotificationsPlugin();
  if (!plugin?.addListener) return null;
  return plugin.addListener('localNotificationActionPerformed', event => {
    callback?.({
      action: event.actionId || 'open',
      activityId: event.notification?.extra?.activityId || null
    });
  });
}

export async function getExactAlarmStatus() {
  if (!isNative()) return { exact_alarm: 'unsupported' };
  const plugin = localNotificationsPlugin();
  if (!plugin?.checkExactNotificationSetting) return { exact_alarm: 'unsupported' };
  return plugin.checkExactNotificationSetting();
}

function numericId(text) {
  let hash = 0;
  for (let i = 0; i < text.length; i++) hash = ((hash << 5) - hash) + text.charCodeAt(i);
  return Math.abs(hash) % 2147483647;
}
